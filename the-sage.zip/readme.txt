﻿The Sage

V1.0.1

Developed with love by RebelKitty (https://discord.com/users/rebelkitty338)

Originally developed from Simplicity Template by Zichqec (https://ukagaka.zichqec.com/).

Simplicity Template v1.0.9 https://github.com/Zichqec/simplicity_template
Using YAYA Tc571-11 https://github.com/yaya-shiori/

Tarot card art comes from Aleister Crowley's Thoth Deck.

This ghost and all its subsequent files are free for public use, but be mindful of any possible restrictions of the aforementioned sources should those be used as well.