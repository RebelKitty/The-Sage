The Sage (shell)
version 1.0.0

Author: RebelKitty

Based on Hozumi's original Ks.Fdmg. 17 (h) Ausf.A freeshell.